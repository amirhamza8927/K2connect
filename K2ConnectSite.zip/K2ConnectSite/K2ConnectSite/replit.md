# Overview

K2Connect is a comprehensive healthcare web application built with modern full-stack technologies. The application serves as a medical services platform that allows patients to book appointments, contact the healthcare facility, and learn about available medical services. The system features a professional medical website with sections for services, team information, testimonials, and contact forms.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built with React and TypeScript using Vite as the build tool. The application follows a component-based architecture with:
- **Routing**: Uses Wouter for client-side routing with dedicated pages for Home, Services, About, and Contact
- **UI Framework**: Implements shadcn/ui components built on top of Radix UI primitives for accessibility and consistency
- **Styling**: Uses Tailwind CSS with custom medical-themed color variables and responsive design
- **State Management**: TanStack Query for server state management and form handling with React Hook Form
- **Animations**: Framer Motion for smooth transitions and interactive elements

## Backend Architecture
The server-side follows a RESTful API pattern built with Express.js:
- **API Design**: RESTful endpoints for appointments (`/api/appointments`) and contacts (`/api/contacts`)
- **Validation**: Zod schemas for input validation and type safety
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Development Setup**: Integrated Vite development server with Hot Module Replacement (HMR)

## Data Storage
The application uses a flexible storage abstraction pattern:
- **Storage Interface**: `IStorage` interface defines operations for users, appointments, and contacts
- **Current Implementation**: In-memory storage (`MemStorage`) for development
- **Database Ready**: Drizzle ORM configuration with PostgreSQL schema definitions prepared for production deployment
- **Schema Management**: Shared schema definitions between client and server using Drizzle-Zod integration

## Form Handling & Validation
- **Client Validation**: React Hook Form with Zod resolvers for type-safe form validation
- **Server Validation**: Matching Zod schemas on the backend ensure data consistency
- **User Feedback**: Toast notifications for success/error states and form submission feedback

## Development & Build Process
- **Development**: TSX with Node.js for server-side development
- **Build System**: Vite for frontend bundling, esbuild for server bundling
- **Type Safety**: Full TypeScript coverage across client, server, and shared code
- **Code Organization**: Monorepo structure with shared types and schemas

# External Dependencies

## UI & Styling
- **shadcn/ui**: Complete component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom medical theme
- **Framer Motion**: Animation library for enhanced user interactions
- **Lucide Icons**: Consistent icon set throughout the application

## Data Management
- **TanStack Query**: Server state management and caching
- **Drizzle ORM**: Type-safe database operations with PostgreSQL support
- **Neon Database**: Serverless PostgreSQL database service (configured)
- **Zod**: Runtime type validation for forms and API endpoints

## Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Type safety across the entire application
- **React Hook Form**: Performant form management with validation
- **Wouter**: Lightweight client-side routing solution

## Production Considerations
- **Database**: PostgreSQL with Drizzle ORM for production deployment
- **Session Management**: connect-pg-simple for PostgreSQL-based sessions
- **Build Output**: Optimized bundles for both client and server deployment
- **Environment Configuration**: Environment-based configuration for database connections