import Navigation from "@/components/navigation";
import AboutSection from "@/components/about-section";
import TeamSection from "@/components/team-section";
import Footer from "@/components/footer";

export default function About() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              About K2Connect
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Learn more about our mission, values, and the dedicated team that makes 
              exceptional healthcare possible.
            </p>
          </div>
        </div>
        <AboutSection />
        <TeamSection />
      </div>
      <Footer />
    </div>
  );
}
