import { motion } from "framer-motion";

export default function AnimatedBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Floating 3D Medical Symbols */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={`medical-symbol-${i}`}
          className="absolute w-16 h-16 opacity-10 medical-cross-3d"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`
          }}
          animate={{
            x: [0, 100, -50, 0],
            y: [0, -80, 120, 0],
            rotateY: [0, 360],
            rotateX: [0, 180, 0],
            scale: [0.5, 1.2, 0.8, 0.5]
          }}
          transition={{
            duration: 20 + Math.random() * 10,
            repeat: Infinity,
            delay: Math.random() * 5,
            ease: "easeInOut"
          }}
        >
          <div className="absolute inset-0 bg-medical-blue/30 rounded-lg"></div>
          <div className="absolute top-1/3 left-0 right-0 h-1/3 bg-medical-blue/40 rounded"></div>
          <div className="absolute left-1/3 top-0 bottom-0 w-1/3 bg-medical-blue/40 rounded"></div>
        </motion.div>
      ))}

      {/* Orbiting DNA Particles */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`dna-particle-${i}`}
          className="absolute w-8 h-8 opacity-20"
          style={{
            left: `${20 + (i * 10)}%`,
            top: `${30 + (i * 8)}%`
          }}
          animate={{
            rotate: [0, 360],
            x: [0, Math.cos(i * 45 * Math.PI / 180) * 200],
            y: [0, Math.sin(i * 45 * Math.PI / 180) * 200],
            scale: [0.5, 1.5, 0.5]
          }}
          transition={{
            duration: 15 + Math.random() * 5,
            repeat: Infinity,
            delay: i * 0.5,
            ease: "linear"
          }}
        >
          <div className="w-full h-full bg-medical-green/40 rounded-full border-2 border-medical-green/20"></div>
        </motion.div>
      ))}

      {/* 3D Geometric Shapes */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={`geo-shape-${i}`}
          className="absolute cube-3d opacity-15"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: `${20 + Math.random() * 40}px`,
            height: `${20 + Math.random() * 40}px`
          }}
          animate={{
            rotateX: [0, 360],
            rotateY: [0, -360],
            rotateZ: [0, 180],
            scale: [0.8, 1.3, 0.8]
          }}
          transition={{
            duration: 12 + Math.random() * 8,
            repeat: Infinity,
            delay: Math.random() * 3,
            ease: "linear"
          }}
        >
          <div className="cube-face bg-medical-orange/30"></div>
          <div className="cube-face bg-medical-blue/30"></div>
          <div className="cube-face bg-medical-green/30"></div>
          <div className="cube-face bg-medical-orange/30"></div>
          <div className="cube-face bg-medical-blue/30"></div>
          <div className="cube-face bg-medical-green/30"></div>
        </motion.div>
      ))}

      {/* Floating Heartbeat Lines */}
      {[...Array(4)].map((_, i) => (
        <motion.div
          key={`heartbeat-${i}`}
          className="absolute opacity-10"
          style={{
            left: `${i * 25}%`,
            top: `${20 + (i * 20)}%`,
            width: '200px',
            height: '60px'
          }}
          animate={{
            x: [0, 100, -100, 0],
            opacity: [0.1, 0.3, 0.1]
          }}
          transition={{
            duration: 8 + i * 2,
            repeat: Infinity,
            delay: i * 1.5,
            ease: "easeInOut"
          }}
        >
          <svg className="w-full h-full" viewBox="0 0 200 60">
            <motion.path
              d="M 0 30 L 40 30 L 50 10 L 60 50 L 70 20 L 80 40 L 90 30 L 200 30"
              stroke={i % 2 === 0 ? "rgba(34, 197, 94, 0.3)" : "rgba(59, 130, 246, 0.3)"}
              strokeWidth="2"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </svg>
        </motion.div>
      ))}

      {/* Prism Light Effects */}
      {[...Array(10)].map((_, i) => (
        <motion.div
          key={`prism-${i}`}
          className="absolute prism-effect rounded-lg opacity-20"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: `${10 + Math.random() * 30}px`,
            height: `${10 + Math.random() * 30}px`
          }}
          animate={{
            rotateZ: [0, 360],
            scale: [0.5, 1.2, 0.5],
            opacity: [0.1, 0.3, 0.1]
          }}
          transition={{
            duration: 6 + Math.random() * 4,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}