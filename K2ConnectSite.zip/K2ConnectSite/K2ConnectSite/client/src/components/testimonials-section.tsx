import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Patient",
    content: "K2Connect provided exceptional care during my recovery. The staff was professional, caring, and always available when I needed them.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=150&h=150&fit=crop&crop=face"
  },
  {
    name: "Michael Chen",
    role: "Patient",
    content: "The 24/7 care service and advanced medical technology at K2Connect made all the difference in my treatment journey.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
  },
  {
    name: "Emily Rodriguez",
    role: "Patient",
    content: "Outstanding medical expertise combined with genuine compassion. K2Connect truly puts patients first in everything they do.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
  }
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-medical-blue/5 via-white to-medical-green/5 dark:from-medical-blue/10 dark:via-gray-900 dark:to-medical-green/10 relative overflow-hidden">
      {/* Floating 3D background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-24 h-24 cube-3d opacity-30">
          <div className="cube-face bg-medical-blue/20"></div>
          <div className="cube-face bg-medical-green/20"></div>
          <div className="cube-face bg-medical-orange/20"></div>
          <div className="cube-face bg-medical-blue/20"></div>
          <div className="cube-face bg-medical-green/20"></div>
          <div className="cube-face bg-medical-orange/20"></div>
        </div>
        
        <div className="absolute bottom-20 right-20 w-32 h-32 spin-ring opacity-40">
          <div className="w-full h-full border-4 border-medical-green/30 rounded-full bg-medical-green/10"></div>
        </div>
        
        <div className="absolute top-1/2 left-1/2 w-16 h-16 dna-helix opacity-25">
          <div className="w-full h-full border-2 border-medical-blue/30 rounded-lg bg-medical-blue/10 prism-effect"></div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50, rotateX: 15 }}
          whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            className="inline-block mb-4"
            initial={{ scale: 0, rotate: -180 }}
            whileInView={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
            viewport={{ once: true }}
          >
            <Quote className="w-12 h-12 text-medical-blue mx-auto animate-bounce-3d" />
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6 text-glow">
            What Our Patients Say
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Real stories from real people who trusted us with their healthcare journey.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              className="flip-card-3d group h-80"
              initial={{ opacity: 0, y: 50, rotateY: -15 }}
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              data-testid={`testimonial-${testimonial.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flip-card-inner h-full">
                {/* Front of Card */}
                <div className="flip-card-front bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700 h-full">
                  <div className="flex flex-col h-full">
                    <div className="flex items-center mb-6">
                      <motion.img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-16 h-16 rounded-full object-cover mr-4 magnetic-3d"
                        whileHover={{ scale: 1.1, rotateY: 15 }}
                      />
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{testimonial.name}</h3>
                        <p className="text-gray-600 dark:text-gray-300">{testimonial.role}</p>
                      </div>
                    </div>
                    
                    <div className="flex mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ scale: 0, rotate: -180 }}
                          whileInView={{ scale: 1, rotate: 0 }}
                          transition={{ delay: 0.1 * i, duration: 0.3 }}
                          viewport={{ once: true }}
                        >
                          <Star className="w-5 h-5 text-yellow-400 fill-current animate-wave" style={{ animationDelay: `${i * 0.2}s` }} />
                        </motion.div>
                      ))}
                    </div>
                    
                    <p className="text-gray-700 dark:text-gray-200 leading-relaxed flex-grow">
                      "{testimonial.content}"
                    </p>
                    
                    <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                      Hover to see more details
                    </div>
                  </div>
                </div>
                
                {/* Back of Card */}
                <div className="flip-card-back bg-gradient-to-br from-medical-blue/20 to-medical-green/20 dark:from-medical-blue/30 dark:to-medical-green/30 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700 h-full">
                  <div className="h-full flex flex-col justify-center items-center text-center">
                    <motion.div 
                      className="w-24 h-24 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center mb-6 perspective-hover"
                      animate={{ rotateY: [0, 360] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    >
                      <Quote className="text-medical-blue w-12 h-12" />
                    </motion.div>
                    
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{testimonial.name}</h3>
                    <p className="text-gray-700 dark:text-gray-200 mb-6 text-lg leading-relaxed">
                      "The level of care and attention I received was beyond my expectations. Every staff member made me feel valued and cared for."
                    </p>
                    
                    <motion.div 
                      className="bg-medical-blue text-white px-6 py-3 rounded-lg font-semibold magnetic-3d"
                      whileHover={{ scale: 1.1 }}
                    >
                      ⭐ {testimonial.rating}/5 Stars
                    </motion.div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}