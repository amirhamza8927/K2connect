import { motion } from "framer-motion";
import { Stethoscope, Heart, Brain, Users, UserCheck, Microscope, ArrowRight } from "lucide-react";

const services = [
  {
    icon: Stethoscope,
    title: "General Medicine",
    description: "Comprehensive primary care services including routine check-ups, preventive care, and treatment of common medical conditions.",
    color: "medical-blue"
  },
  {
    icon: Heart,
    title: "Cardiology",
    description: "Expert cardiac care including heart health assessments, treatment of cardiovascular conditions, and preventive cardiology.",
    color: "medical-green"
  },
  {
    icon: Brain,
    title: "Neurology",
    description: "Specialized neurological care for brain and nervous system disorders, including diagnosis and treatment of neurological conditions.",
    color: "medical-orange"
  },
  {
    icon: Users,
    title: "Pediatrics",
    description: "Comprehensive healthcare for children from infancy through adolescence, including wellness visits, vaccinations, and pediatric treatments.",
    color: "purple-500"
  },
  {
    icon: UserCheck,
    title: "Women's Health",
    description: "Specialized care for women including gynecological services, reproductive health, prenatal care, and wellness programs.",
    color: "pink-500"
  },
  {
    icon: Microscope,
    title: "Laboratory Services",
    description: "Comprehensive diagnostic testing and laboratory services with accurate results and quick turnaround times.",
    color: "indigo-500"
  }
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-gray-50 dark:bg-gray-900 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-32 h-32 bg-medical-blue/5 dark:bg-medical-blue/10 rounded-full animate-float"></div>
        <div className="absolute bottom-20 right-20 w-24 h-24 bg-medical-green/5 dark:bg-medical-green/10 rounded-full animate-pulse-slow"></div>
        <div className="absolute top-1/2 right-10 w-16 h-16 bg-medical-orange/5 dark:bg-medical-orange/10 rounded-full animate-rotate-3d"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50, rotateX: 15 }}
          whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            className="inline-block mb-4"
            initial={{ scale: 0, rotate: -180 }}
            whileInView={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
            viewport={{ once: true }}
          >
            <div className="w-12 h-1 bg-gradient-to-r from-medical-blue to-medical-green rounded-full mx-auto"></div>
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6 text-glow">
            Our Medical Services
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Comprehensive healthcare services designed to meet all your medical needs 
            with state-of-the-art technology and compassionate care.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={service.title}
                className="flip-card-3d group"
                initial={{ opacity: 0, y: 50, rotateY: -15 }}
                whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                data-testid={`card-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="flip-card-inner">
                  {/* Front of Card */}
                  <div className="flip-card-front bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
                    <motion.div 
                      className={`w-16 h-16 bg-${service.color} bg-opacity-10 dark:bg-opacity-20 rounded-xl flex items-center justify-center mb-6 relative magnetic-3d`}
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      <IconComponent className={`text-${service.color} w-8 h-8`} />
                      <div className={`absolute inset-0 rounded-xl bg-${service.color} opacity-0 group-hover:opacity-20 transition-opacity duration-300`}></div>
                    </motion.div>
                    
                    <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">{service.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                      {service.description}
                    </p>
                    
                    <motion.button 
                      className={`text-${service.color} font-semibold flex items-center space-x-2 group-hover:space-x-3 transition-all duration-300 group/btn`}
                      whileHover={{ x: 5 }}
                      data-testid={`button-learn-more-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <span>Hover to flip</span>
                      <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                    </motion.button>
                  </div>
                  
                  {/* Back of Card */}
                  <div className={`flip-card-back bg-gradient-to-br from-${service.color}/20 to-${service.color}/5 dark:from-${service.color}/30 dark:to-${service.color}/10 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700`}>
                    <div className="h-full flex flex-col justify-center items-center text-center">
                      <motion.div 
                        className={`w-20 h-20 bg-${service.color} bg-opacity-20 dark:bg-opacity-30 rounded-full flex items-center justify-center mb-6 animate-bounce-3d`}
                      >
                        <IconComponent className={`text-${service.color} w-10 h-10`} />
                      </motion.div>
                      
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{service.title}</h3>
                      <p className="text-gray-700 dark:text-gray-200 mb-6 text-lg leading-relaxed">
                        Advanced healthcare technology with personalized treatment plans designed for optimal outcomes.
                      </p>
                      
                      <motion.button 
                        className={`bg-${service.color} text-white px-6 py-3 rounded-lg font-semibold perspective-hover`}
                        whileHover={{ scale: 1.1 }}
                        data-testid={`button-contact-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        Contact Specialist
                      </motion.button>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
