import { Button } from "@/components/ui/button";
import { Calendar, Play, ChevronDown, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-white via-medical-blue/5 to-medical-green/10 dark:from-gray-900 dark:via-medical-blue/20 dark:to-medical-green/20">
      {/* 3D Animated Background instead of image */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Large rotating medical cross */}
        <motion.div 
          className="absolute top-1/4 left-1/4 w-32 h-32 medical-cross-3d"
          animate={{ 
            rotateY: [0, 360], 
            rotateX: [0, 180, 0],
            scale: [1, 1.2, 1]
          }}
          transition={{ 
            duration: 20, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        >
          <div className="absolute inset-0 bg-medical-blue/20 rounded-lg"></div>
          <div className="absolute top-1/3 left-0 right-0 h-1/3 bg-medical-blue/30 rounded"></div>
          <div className="absolute left-1/3 top-0 bottom-0 w-1/3 bg-medical-blue/30 rounded"></div>
        </motion.div>

        {/* DNA double helix structure */}
        <motion.div 
          className="absolute top-10 right-20 w-24 h-48 dna-double-helix"
          animate={{ rotateZ: [0, 360] }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        >
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-4 h-4 bg-medical-green/40 rounded-full"
              style={{
                left: `${Math.cos(i * 30 * Math.PI / 180) * 20 + 20}px`,
                top: `${i * 16}px`
              }}
              animate={{
                rotateY: [0, 360],
                scale: [0.8, 1.2, 0.8]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.2
              }}
            />
          ))}
        </motion.div>

        {/* Floating heart beat monitor line */}
        <motion.div 
          className="absolute bottom-20 left-10 w-64 h-32 heartbeat-monitor"
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <svg className="w-full h-full" viewBox="0 0 256 128">
            <motion.path
              d="M 0 64 L 50 64 L 60 20 L 70 100 L 80 40 L 90 80 L 100 64 L 256 64"
              stroke="rgba(34, 197, 94, 0.6)"
              strokeWidth="3"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
          </svg>
        </motion.div>

        {/* Orbiting medical symbols */}
        <motion.div 
          className="absolute top-1/2 right-1/3 w-40 h-40"
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        >
          {['stethoscope', 'pill', 'syringe', 'bandage'].map((symbol, i) => (
            <motion.div
              key={symbol}
              className="absolute w-8 h-8 bg-medical-orange/40 rounded-full flex items-center justify-center text-medical-orange"
              style={{
                left: `${Math.cos(i * 90 * Math.PI / 180) * 60 + 60}px`,
                top: `${Math.sin(i * 90 * Math.PI / 180) * 60 + 60}px`
              }}
              animate={{
                scale: [0.8, 1.3, 0.8],
                rotateY: [0, 360]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                delay: i * 0.5
              }}
            >
              {symbol[0].toUpperCase()}
            </motion.div>
          ))}
        </motion.div>
      </div>
      
      {/* 3D Floating Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Floating Particles */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={`particle-${i}`}
            className="absolute w-3 h-3 bg-white/20 rounded-full animate-wave"
            initial={{ 
              x: Math.random() * window.innerWidth, 
              y: Math.random() * window.innerHeight 
            }}
            animate={{
              y: [0, -60, 0],
              x: [0, 40, 0],
              opacity: [0.2, 1, 0.2],
              scale: [0.5, 1.2, 0.5]
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 4
            }}
          />
        ))}
        
        {/* 3D Rotating Cubes */}
        <div className="absolute top-20 right-20 cube-3d">
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
        </div>
        
        <div className="absolute bottom-32 left-16 cube-3d" style={{ animationDelay: '2s' }}>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
          <div className="cube-face"></div>
        </div>
        
        {/* DNA Helix Medical Symbol */}
        <div className="absolute top-1/3 left-10 w-16 h-16 dna-helix">
          <div className="w-full h-full border-2 border-medical-green/30 rounded-full bg-medical-green/10"></div>
        </div>
        
        {/* Prism Light Effects */}
        <div className="absolute top-1/4 right-1/4 w-20 h-20 prism-effect rounded-lg opacity-30"></div>
        <div className="absolute bottom-1/4 left-1/3 w-12 h-12 prism-effect rounded-full opacity-40" style={{ animationDelay: '1.5s' }}></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 50, rotateX: 15 }}
          animate={{ opacity: 1, y: 0, rotateX: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <motion.div
            className="inline-flex items-center px-4 py-2 bg-white/10 glass-effect rounded-full mb-6"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <Sparkles className="w-4 h-4 text-medical-green mr-2" />
            <span className="text-white text-sm font-medium">Premium Healthcare Excellence</span>
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-gray-900 dark:text-white mb-6 leading-tight text-glow relative z-20 backdrop-blur-sm bg-white/10 dark:bg-gray-900/20 rounded-2xl p-4"
            initial={{ opacity: 0, y: 30, rotateX: 15 }}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <motion.span 
              className="inline-block"
              animate={{ rotateY: [0, 5, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              Your Health,
            </motion.span>{" "}
            <motion.span 
              className="text-medical-green animate-pulse-glow inline-block perspective-hover"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              Our Priority
            </motion.span>
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-gray-800 dark:text-gray-100 mb-8 max-w-3xl mx-auto leading-relaxed backdrop-blur-sm bg-white/20 dark:bg-gray-900/30 rounded-xl p-6 relative z-20"
            initial={{ opacity: 0, y: 30, rotateX: 10 }}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <motion.span
              animate={{ opacity: [0.8, 1, 0.8] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              Experience compassionate, comprehensive medical care with K2Connect. 
              Our expert team is dedicated to providing personalized healthcare solutions for you and your family.
            </motion.span>
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.8 }}
          >
            <Button 
              onClick={() => scrollToSection("appointment")}
              className="bg-white text-medical-blue px-8 py-4 rounded-lg text-lg font-semibold morphing-card flex items-center space-x-2 hover:bg-gray-50 hover:shadow-2xl"
              data-testid="button-book-appointment-hero"
            >
              <Calendar className="w-5 h-5" />
              <span>Book Appointment</span>
            </Button>
            <Button 
              onClick={() => scrollToSection("about")}
              variant="outline"
              className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold morphing-card flex items-center space-x-2 hover:bg-white hover:text-medical-blue glass-effect"
              data-testid="button-learn-more-hero"
            >
              <Play className="w-5 h-5" />
              <span>Learn More</span>
            </Button>
          </motion.div>
        </motion.div>
      </div>

      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white floating-animation"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="w-8 h-8" />
      </motion.div>
    </section>
  );
}
