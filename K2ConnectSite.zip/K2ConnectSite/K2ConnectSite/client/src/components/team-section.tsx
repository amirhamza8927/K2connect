import { motion } from "framer-motion";
import { Linkedin, Mail } from "lucide-react";

const teamMembers = [
  {
    name: "Dr. Sarah Johnson",
    specialty: "Chief Cardiologist",
    bio: "15+ years experience in interventional cardiology. Specializes in cardiac catheterization and heart disease prevention.",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
    color: "medical-blue"
  },
  {
    name: "Dr. Michael Chen",
    specialty: "Neurologist",
    bio: "Board-certified neurologist with expertise in stroke treatment and neurological rehabilitation programs.",
    image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
    color: "medical-green"
  },
  {
    name: "Dr. Emily Rodriguez",
    specialty: "Pediatrician",
    bio: "Dedicated pediatrician with a passion for child development and family-centered care approaches.",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
    color: "purple-500"
  }
];

export default function TeamSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Meet Our Expert Team</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our dedicated team of healthcare professionals brings years of experience 
            and a passion for delivering exceptional patient care.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={member.name}
              className="bg-white rounded-2xl p-8 text-center shadow-lg card-hover"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
              data-testid={`card-doctor-${member.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <img 
                src={member.image}
                alt={`${member.name}, ${member.specialty}`}
                className="w-32 h-32 rounded-full mx-auto mb-6 object-cover"
              />
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">{member.name}</h3>
              <p className={`text-${member.color} font-medium mb-4`}>{member.specialty}</p>
              <p className="text-gray-600 leading-relaxed mb-6">
                {member.bio}
              </p>
              <div className="flex justify-center space-x-4">
                <button 
                  className={`text-${member.color} hover:opacity-80 transition-opacity`}
                  data-testid={`button-linkedin-${member.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Linkedin className="w-5 h-5" />
                </button>
                <button 
                  className={`text-${member.color} hover:opacity-80 transition-opacity`}
                  data-testid={`button-email-${member.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Mail className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
