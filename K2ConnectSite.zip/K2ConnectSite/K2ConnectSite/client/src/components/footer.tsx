import { Heart, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const quickLinks = [
  { href: "/services", label: "Our Services" },
  { href: "/about", label: "About Us" },
  { href: "/#testimonials", label: "Testimonials" },
  { href: "/contact", label: "Contact" },
  { href: "#", label: "Patient Portal" },
  { href: "#", label: "Insurance" }
];

const contactDetails = [
  { icon: "map-marker", text: "123 Healthcare Avenue" },
  { icon: "phone", text: "(555) 123-4567" },
  { icon: "envelope", text: "info@k2connect.com" },
  { icon: "clock", text: "24/7 Emergency Care" }
];

const socialLinks = [
  { icon: Facebook, href: "#", name: "Facebook" },
  { icon: Twitter, href: "#", name: "Twitter" },
  { icon: Instagram, href: "#", name: "Instagram" },
  { icon: Linkedin, href: "#", name: "LinkedIn" }
];

export default function Footer() {
  return (
    <footer className="bg-gray-900 dark:bg-black text-white py-16 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 right-10 w-24 h-24 bg-medical-blue/10 rounded-full animate-pulse-slow"></div>
        <div className="absolute bottom-10 left-20 w-16 h-16 bg-medical-green/10 rounded-full animate-float"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-medical-blue rounded-lg flex items-center justify-center">
                <Heart className="text-white w-6 h-6" />
              </div>
              <span className="text-2xl font-bold">K2Connect</span>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed max-w-md">
              Providing exceptional medical care with compassion, innovation, and excellence. 
              Your health and well-being are our top priorities.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <motion.button 
                    key={social.name}
                    className="w-10 h-10 bg-gray-800 dark:bg-gray-700 rounded-lg flex items-center justify-center hover:bg-medical-blue dark:hover:bg-medical-blue transition-all duration-300 magnetic-3d"
                    whileHover={{ scale: 1.2, rotateY: 15, rotateX: 15 }}
                    whileTap={{ scale: 0.9 }}
                    data-testid={`button-social-${social.name.toLowerCase()}`}
                  >
                    <IconComponent className="w-5 h-5" />
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={`${link.href}-${index}`}>
                  {link.href.startsWith('#') ? (
                    <a 
                      href={link.href}
                      className="text-gray-300 hover:text-white transition-colors duration-300"
                      data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {link.label}
                    </a>
                  ) : (
                    <Link 
                      href={link.href}
                      className="text-gray-300 hover:text-white transition-colors duration-300"
                      data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {link.label}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Contact Info</h3>
            <ul className="space-y-3">
              {contactDetails.map((contact, index) => (
                <li key={index} className="text-gray-300">
                  {contact.text}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 dark:border-gray-700 mt-12 pt-8 text-center">
          <p className="text-gray-400 dark:text-gray-500">
            © 2024 K2Connect Medical Care. All rights reserved. | 
            <a href="#" className="hover:text-white dark:hover:text-gray-300 transition-colors duration-300 ml-1">Privacy Policy</a> | 
            <a href="#" className="hover:text-white dark:hover:text-gray-300 transition-colors duration-300 ml-1">Terms of Service</a>
          </p>
        </div>
      </div>
    </footer>
  );
}
