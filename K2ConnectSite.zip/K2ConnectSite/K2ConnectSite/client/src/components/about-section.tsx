import { motion } from "framer-motion";
import { Award, Users, Clock } from "lucide-react";

const features = [
  {
    icon: Award,
    title: "Award-Winning Care",
    description: "Recognized for excellence in patient care and medical innovation.",
    color: "medical-blue"
  },
  {
    icon: Users,
    title: "Expert Medical Team",
    description: "Board-certified physicians and specialists with extensive experience.",
    color: "medical-green"
  },
  {
    icon: Clock,
    title: "24/7 Emergency Care",
    description: "Round-the-clock emergency services and urgent care availability.",
    color: "medical-orange"
  }
];

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-800 relative overflow-hidden">
      {/* Background decorative gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-medical-blue/5 via-transparent to-medical-green/5 dark:from-medical-blue/10 dark:to-medical-green/10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50, rotateY: -15 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.h2 
              className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              viewport={{ once: true }}
            >
              Why Choose <span className="text-medical-blue text-glow">K2Connect?</span>
            </motion.h2>
            
            <motion.p 
              className="text-xl text-gray-600 dark:text-gray-300 mb-8 leading-relaxed"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              viewport={{ once: true }}
            >
              With over 15 years of experience in healthcare, K2Connect has been 
              at the forefront of medical innovation, providing exceptional care 
              to thousands of patients across the region.
            </motion.p>
            
            <div className="space-y-6">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    className="flex items-start space-x-4 group"
                    initial={{ opacity: 0, x: -30, rotateX: 15 }}
                    whileInView={{ opacity: 1, x: 0, rotateX: 0 }}
                    whileHover={{ x: 10, scale: 1.02 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    data-testid={`feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <motion.div 
                      className={`w-12 h-12 bg-${feature.color} bg-opacity-10 dark:bg-opacity-20 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      <IconComponent className={`text-${feature.color} w-6 h-6`} />
                    </motion.div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 group-hover:text-medical-blue dark:group-hover:text-medical-blue transition-colors">
                        {feature.title}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50, rotateY: 15 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            whileHover={{ scale: 1.05, rotateY: -5 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-medical-blue to-medical-green rounded-2xl blur-2xl opacity-20 animate-pulse-glow"></div>
            <img 
              src="https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Modern medical facility with healthcare professionals" 
              className="rounded-2xl shadow-2xl w-full h-auto relative z-10 morphing-card"
            />
            
            {/* 3D Floating badges with enhanced animations */}
            <motion.div
              className="absolute -top-4 -right-4 bg-white dark:bg-gray-800 rounded-xl p-3 shadow-lg glass-effect magnetic-3d"
              animate={{ y: [0, -10, 0], rotateY: [0, 360, 0] }}
              transition={{ duration: 6, repeat: Infinity }}
            >
              <div className="text-medical-blue text-2xl font-bold">15+</div>
              <div className="text-xs text-gray-600 dark:text-gray-300">Years</div>
            </motion.div>
            
            <motion.div
              className="absolute -bottom-4 -left-4 bg-white dark:bg-gray-800 rounded-xl p-3 shadow-lg glass-effect perspective-hover"
              animate={{ y: [0, 10, 0], rotateX: [0, 360, 0] }}
              transition={{ duration: 8, repeat: Infinity, delay: 1 }}
            >
              <div className="text-medical-green text-2xl font-bold">24/7</div>
              <div className="text-xs text-gray-600 dark:text-gray-300">Care</div>
            </motion.div>
            
            {/* Additional 3D floating elements */}
            <motion.div
              className="absolute top-1/2 -right-8 w-16 h-16 spin-ring"
              animate={{ rotateZ: [0, 360] }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            >
              <div className="w-full h-full border-4 border-medical-orange/40 rounded-full bg-medical-orange/10"></div>
            </motion.div>
            
            <motion.div
              className="absolute top-10 -left-6 w-12 h-12 dna-helix"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              <div className="w-full h-full border-2 border-medical-blue/40 rounded-lg bg-medical-blue/10 prism-effect"></div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
