import { motion } from "framer-motion";
import { Phone, MessageCircle, X } from "lucide-react";
import { useState } from "react";

export default function FloatingContact() {
  const [isExpanded, setIsExpanded] = useState(false);

  const contactOptions = [
    {
      icon: Phone,
      label: "Call Now",
      action: () => window.open("tel:+15551234567"),
      color: "bg-medical-blue",
      delay: 0.1
    },
    {
      icon: MessageCircle,
      label: "Live Chat",
      action: () => console.log("Starting live chat..."),
      color: "bg-medical-green",
      delay: 0.2
    }
  ];

  return (
    <div className="fixed bottom-8 right-8 z-50">
      {/* Expanded contact options */}
      {isExpanded && (
        <motion.div
          className="absolute bottom-20 right-0 space-y-3"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5 }}
          transition={{ duration: 0.3 }}
        >
          {contactOptions.map((option, index) => {
            const IconComponent = option.icon;
            return (
              <motion.button
                key={option.label}
                onClick={option.action}
                className={`${option.color} text-white p-4 rounded-full shadow-lg magnetic-3d group flex items-center space-x-3 pr-6`}
                initial={{ opacity: 0, x: 50, rotateY: -90 }}
                animate={{ opacity: 1, x: 0, rotateY: 0 }}
                transition={{ delay: option.delay, duration: 0.4 }}
                whileHover={{ scale: 1.1, rotateX: 10, rotateY: 10 }}
                whileTap={{ scale: 0.95 }}
                data-testid={`floating-${option.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="perspective-hover">
                  <IconComponent className="w-6 h-6" />
                </div>
                <span className="text-sm font-medium">{option.label}</span>
              </motion.button>
            );
          })}
        </motion.div>
      )}

      {/* Main floating button */}
      <motion.button
        onClick={() => setIsExpanded(!isExpanded)}
        className={`w-16 h-16 rounded-full shadow-lg text-white flex items-center justify-center magnetic-3d ${
          isExpanded ? 'bg-red-500' : 'bg-medical-blue'
        }`}
        whileHover={{ 
          scale: 1.2, 
          rotateX: 15, 
          rotateY: 15,
          boxShadow: "0 20px 40px rgba(0, 0, 0, 0.3)"
        }}
        whileTap={{ scale: 0.9 }}
        animate={{ 
          y: [0, -10, 0],
          rotateZ: isExpanded ? 180 : 0
        }}
        transition={{ 
          y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
          rotateZ: { duration: 0.3 }
        }}
        data-testid="floating-contact-toggle"
      >
        {isExpanded ? <X className="w-8 h-8" /> : <Phone className="w-8 h-8" />}
        
        {/* Pulsing ring effect */}
        <motion.div
          className="absolute inset-0 rounded-full border-4 border-white/30"
          animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        
        {/* Secondary pulsing ring */}
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-white/20"
          animate={{ scale: [1, 2, 1], opacity: [1, 0, 1] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
        />
      </motion.button>

      {/* Floating particles around the button */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-medical-blue/30 rounded-full"
          animate={{
            x: [0, Math.cos(i * 60 * Math.PI / 180) * 40],
            y: [0, Math.sin(i * 60 * Math.PI / 180) * 40],
            opacity: [0, 1, 0],
            scale: [0.5, 1, 0.5]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: i * 0.2,
            ease: "easeInOut"
          }}
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)'
          }}
        />
      ))}
    </div>
  );
}